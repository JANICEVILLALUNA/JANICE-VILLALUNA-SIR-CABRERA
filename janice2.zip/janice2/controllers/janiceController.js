/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { Janice } from "../models/Janice.js";
import { sequelize } from "../models/db.js";
await sequelize.sync();

const janice = {
  index: async (req, res) => {
    const data = await Janice.findAll();
    res.render("janice", { data });
  },

  insert: async (req, res) => {
    const { FirstName, LastName, MiddleName, Age, Gender, Section } = req.body;
    const data = await Janice.create({ FirstName, LastName, MiddleName, Age, Gender, Section });

    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json(data);
    }
    res.redirect("/janice2"); // Naitama na patungong janice2
  },

  get: async (req, res) => {
    const data = await Janice.findAll();
    res.json(data);
  },

  show: async (req, res) => {
    const { id } = req.params;
    const data = await Janice.findByPk(id);
    res.json(data);
  },

  update: async (req, res) => {
    const { id } = req.params;
    const { FirstName, LastName, MiddleName, Age, Gender, Section } = req.body;

    await Janice.update(
      { FirstName, LastName, MiddleName, Age, Gender, Section },
      { where: { id } }
    );

    const updatedData = await Janice.findByPk(id);
    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json(updatedData);
    }
    res.redirect("/janice2"); // Naitama na patungong janice2
  },

  delete: async (req, res) => {
    const { id } = req.params;
    await Janice.destroy({ where: { id } });

    const isJson = req.headers["content-type"]?.includes("application/json");
    if (isJson) {
      return res.json({ message: "Deleted successfully" });
    }
    res.redirect("/janice2"); // Naitama na patungong janice2
  }
};

export { janice };